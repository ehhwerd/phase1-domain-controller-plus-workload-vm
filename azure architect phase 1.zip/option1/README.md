# Dicker Data Deployment Template #1

This template creates a VM, installes domain services, updates DNS of the VNet, downloads AD Connect so its ready to connect to an Azure Active Directory, deploys second VM and joins to domain

### REQUIREMENTS
1. Parameters

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fehhwerd%2Fphase1-domain-controller-plus-workload-vm%2Fmaster%2Foption1%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>


